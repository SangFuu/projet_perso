# Petit projet : deviner un nombre

Projet de SangFuu. Malgré son nom historique « Pendu », cette version consiste à deviner un nombre entre 0 et 100, avec cinq vies et des indications « plus » ou « moins ».

## Jouer

Avec GCC, depuis le dossier du projet :

```sh
gcc -std=c11 -Wall -Wextra -Wpedantic -Werror main.c mycode.c -o pendu
./pendu
```

Sous Windows, utiliser `-o pendu.exe`, puis lancer `./pendu.exe`. GCC est notamment fourni avec l'environnement MinGW de CLion. Le projet Code::Blocks existant est également conservé.

Avec CMake, pour CLion ou un autre environnement :

```sh
cmake -S . -B build
cmake --build build
```

L'emplacement de l'exécutable dans `build` dépend du générateur choisi.

## Règles

- Un nombre entier compris entre 0 et 100 est accepté.
- Chaque proposition valide et incorrecte retire une vie.
- Le texte, les nombres hors limites et les lignes trop longues sont refusés sans perte de vie.
- La partie se termine à la victoire, après cinq erreurs ou à la fermeture de l'entrée.

## Vérification

Les tests demandent GCC et PowerShell 7 :

```powershell
pwsh -File tests/test.ps1
# Si GCC n'est pas dans le PATH :
pwsh -File tests/test.ps1 -Compiler 'chemin/vers/gcc.exe'
```

Neuf scénarios vérifient la victoire immédiate et au dernier essai, la défaite, les saisies incorrectes, les lignes trop longues, les espaces et la fin de saisie. Le nombre attendu est déterminé à partir d'une graine fixe uniquement dans le programme de test ; le jeu normal utilise une graine liée à l'heure.

## Corrections

Le programme lance maintenant réellement le jeu. Sa fonction est déclarée dans l'en-tête. Les saisies sont entièrement vérifiées, sans utiliser une valeur non initialisée ni rester bloqué sur du texte. Les sources sont accessibles directement et l'archive `Petit__Projet_Pendu.zip` contient cette version corrigée, sans exécutables ni objets compilés.

Validation locale : GCC/MinGW, C11, `-Wall -Wextra -Wpedantic -Werror`, neuf tests réussis. Cela couvre les scénarios décrits, sans constituer une garantie d'absence de tout défaut.
